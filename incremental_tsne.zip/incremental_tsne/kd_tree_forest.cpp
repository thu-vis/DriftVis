/*
 *  kd_tree_forest.cpp
 *  Implementation of kd_tree forest.
 *
 *  Created by Shouxing Xiang.
 */

